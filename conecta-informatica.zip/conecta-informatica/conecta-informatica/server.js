// Carrega as variáveis do arquivo .env
require('dotenv').config();

const express = require('express');
const path = require('path');
const configurarRotas = require('./index');

const app = express();
const PORT = process.env.PORT || 3000;

// Permite receber dados dos formulários
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Configura as páginas EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Página inicial
app.get('/', (req, res) => {
    res.redirect('/produtos');
});

// Registra as rotas
configurarRotas(app);

// Inicia o servidor
app.listen(PORT, () => {
    console.log(`Servidor iniciado em http://localhost:${PORT}`);
});