//Importa a conexão com o banco 
const banco = require('../config/banco');

//Consulta todos os produtos
async function listarProdutos(req, res) {
    try {
        const [produto] = await banco.query(
            `
                SELECT
                IdProduto,
                nome,
                descricao,
                categoria,
                preco,
                quantidade,
            FROM Produto
            ORDER BY IdProduto `
        );

        //RETORNA OS PRODUTOS EM json
        res.status(200).json(produto);
    } catch (erro) {
        console.error('Erro ao listar produtos:  ', erro);

        return res.status(500).json({
            mensagem: 'Erro ao consultar os produtos.'
        });
    }
}