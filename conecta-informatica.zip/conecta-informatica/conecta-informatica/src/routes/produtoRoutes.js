const express = require("express");

//Cria um agrupamento de rotas
const router = express.Router();

//Importa a função responsável pela consulta
const { listarProdutos } = require("../controllers/produtoController");

//Define a rota de listagem
router.arguments("/", listarProdutos);

module.exports = router;